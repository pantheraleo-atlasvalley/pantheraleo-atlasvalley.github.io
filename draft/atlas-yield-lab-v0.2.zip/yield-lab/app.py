#!/usr/bin/env python3
"""Local, single-user demo ledger for the Atlas Valley Yield Lab.

This is a simulation only. It does not connect to a wallet, blockchain, or yield
provider and must never be used to account for real assets.
"""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse


ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "yield-lab.sqlite3"
HOST = "127.0.0.1"
PORT = int(os.environ.get("YIELD_LAB_PORT", "8787"))
FEE_BPS = 0  # Demo only. A production fee schedule has not been selected.
MAX_BODY = 4096


def connect_db() -> sqlite3.Connection:
    db = sqlite3.connect(DB_PATH, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA foreign_keys=ON")
    return db


def canonical(value: dict) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def digest_event(event: dict) -> str:
    fields = {key: event[key] for key in ("sequence", "created_at", "kind", "amount", "fee", "note", "previous_hash")}
    return hashlib.sha256(canonical(fields)).hexdigest()


def initialize() -> None:
    with connect_db() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS events (
            sequence INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            kind TEXT NOT NULL,
            amount INTEGER NOT NULL,
            fee INTEGER NOT NULL,
            note TEXT NOT NULL,
            previous_hash TEXT NOT NULL,
            event_hash TEXT NOT NULL UNIQUE
        )""")
        if db.execute("SELECT COUNT(*) FROM events").fetchone()[0] == 0:
            genesis = {
                "sequence": 1,
                "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "kind": "genesis",
                "amount": 0,
                "fee": 0,
                "note": "Registro demo inizializzato; nessun asset reale.",
                "previous_hash": "0" * 64,
            }
            db.execute(
                "INSERT INTO events(sequence,created_at,kind,amount,fee,note,previous_hash,event_hash) VALUES(?,?,?,?,?,?,?,?)",
                (*[genesis[k] for k in ("sequence", "created_at", "kind", "amount", "fee", "note", "previous_hash")], digest_event(genesis)),
            )


def all_events(db: sqlite3.Connection) -> list[dict]:
    return [dict(row) for row in db.execute("SELECT * FROM events ORDER BY sequence")]


def verify(events: list[dict]) -> bool:
    previous = "0" * 64
    for index, event in enumerate(events, start=1):
        if event["sequence"] != index or event["previous_hash"] != previous:
            return False
        if digest_event(event) != event["event_hash"]:
            return False
        previous = event["event_hash"]
    return bool(events)


def ledger_state(events: list[dict]) -> dict:
    available = 0
    staked = 0
    deposited = 0
    withdrawn = 0
    fees = 0
    for event in events:
        amount, fee, kind = event["amount"], event["fee"], event["kind"]
        if kind == "deposit":
            available += amount - fee
            deposited += amount
        elif kind == "withdraw":
            available -= amount
            withdrawn += amount
            fees += fee
        elif kind == "stake":
            available -= amount
            staked += amount
        elif kind == "unstake":
            staked -= amount
            available += amount
    return {"available": available, "staked": staked, "deposited": deposited, "withdrawn": withdrawn, "fees": fees}


class Handler(BaseHTTPRequestHandler):
    server_version = "AtlasYieldLab/0.1"

    def log_message(self, fmt: str, *args: object) -> None:
        print(f"[{self.log_date_time_string()}] {fmt % args}")

    def send_json(self, status: int, value: dict) -> None:
        payload = json.dumps(value, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        atlaslabs_files = {
            "/atlaslabs": (ROOT.parent / "atlaslabs" / "index.html", "text/html; charset=utf-8"),
            "/atlaslabs/": (ROOT.parent / "atlaslabs" / "index.html", "text/html; charset=utf-8"),
            "/atlaslabs/login": (ROOT.parent / "atlaslabs" / "login" / "index.html", "text/html; charset=utf-8"),
            "/atlaslabs/login/": (ROOT.parent / "atlaslabs" / "login" / "index.html", "text/html; charset=utf-8"),
            "/atlaslabs/app.css": (ROOT.parent / "atlaslabs" / "app.css", "text/css; charset=utf-8"),
            "/atlaslabs/dashboard.css": (ROOT.parent / "atlaslabs" / "dashboard.css", "text/css; charset=utf-8"),
            "/atlaslabs/dashboard-v02.css": (ROOT.parent / "atlaslabs" / "dashboard-v02.css", "text/css; charset=utf-8"),
            "/atlaslabs/lab.js": (ROOT.parent / "atlaslabs" / "lab.js", "text/javascript; charset=utf-8"),
            "/atlaslabs/config.js": (ROOT.parent / "atlaslabs" / "config.js", "text/javascript; charset=utf-8"),
            "/atlaslabs/login.js": (ROOT.parent / "atlaslabs" / "login.js", "text/javascript; charset=utf-8"),
            "/atlaslabs/protocol.md": (ROOT.parent / "atlaslabs" / "protocol.md", "text/markdown; charset=utf-8"),
        }
        if path in atlaslabs_files:
            file_path, content_type = atlaslabs_files[path]
            try:
                content = file_path.read_bytes()
            except OSError:
                self.send_error(404)
                return
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(content)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(content)
            return
        if path == "/api/state":
            with connect_db() as db:
                events = all_events(db)
            self.send_json(200, {"mode": "simulation", "unit": "DEMO", "fee_bps": FEE_BPS,
                                 "state": ledger_state(events), "verified": verify(events),
                                 "events": list(reversed(events)), "total_events": len(events)})
            return
        if path == "/" or path == "/index.html":
            content = (ROOT / "index.html").read_bytes()
            content_type = "text/html; charset=utf-8"
        elif path in ("/style.css", "/app.js", "/protocol.md"):
            filename = path[1:]
            content = (ROOT / filename).read_bytes()
            content_type = {"style.css": "text/css; charset=utf-8", "app.js": "text/javascript; charset=utf-8", "protocol.md": "text/markdown; charset=utf-8"}[filename]
        else:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(content)

    def do_POST(self) -> None:
        if urlparse(self.path).path != "/api/action":
            self.send_json(404, {"error": "Endpoint non trovato."})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 1 <= length <= MAX_BODY:
                raise ValueError("Richiesta vuota o troppo grande.")
            body = json.loads(self.rfile.read(length))
            kind = body.get("kind")
            amount = body.get("amount")
            if kind not in {"deposit", "withdraw", "stake", "unstake"}:
                raise ValueError("Operazione non riconosciuta.")
            if not isinstance(amount, int) or isinstance(amount, bool) or not 1 <= amount <= 1_000_000_000:
                raise ValueError("Inserisci un importo intero in DEMO, da 1 a 1.000.000.000.")
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            self.send_json(400, {"error": str(exc)})
            return

        with connect_db() as db:
            db.execute("BEGIN IMMEDIATE")
            events = all_events(db)
            balances = ledger_state(events)
            required = "staked" if kind == "unstake" else "available"
            if kind in {"withdraw", "stake", "unstake"} and amount > balances[required]:
                db.rollback()
                self.send_json(409, {"error": f"Saldo {required} insufficiente: {balances[required]} DEMO."})
                return
            fee = (amount * FEE_BPS + 9_999) // 10_000 if kind in {"deposit", "withdraw"} else 0
            previous = events[-1]["event_hash"]
            event = {
                "sequence": len(events) + 1,
                "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "kind": kind,
                "amount": amount,
                "fee": fee,
                "note": {
                    "deposit": "Deposito simulato: DEMO creati solo nel registro locale.",
                    "withdraw": "Prelievo simulato: nessuna criptovaluta trasferita.",
                    "stake": "Allocazione simulata; nessun validator o protocollo esterno coinvolto.",
                    "unstake": "Rientro simulato dall'allocazione.",
                }[kind],
                "previous_hash": previous,
            }
            event_hash = digest_event(event)
            db.execute("INSERT INTO events(created_at,kind,amount,fee,note,previous_hash,event_hash) VALUES(?,?,?,?,?,?,?)",
                       (event["created_at"], kind, amount, fee, event["note"], previous, event_hash))
            db.commit()
        self.send_json(201, {"ok": True, "hash": event_hash})


if __name__ == "__main__":
    initialize()
    print("Atlas Valley Yield Lab v0.1 · SIMULAZIONE LOCALE · nessun asset reale")
    print(f"Apri http://{HOST}:{PORT} (Ctrl+C per chiudere)")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
