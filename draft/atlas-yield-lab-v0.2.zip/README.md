# Atlas Valley

Atlas Valley website and project documentation.

- Main website: `index.html`
- Documentation portal: `docs/index.html`
- Docs styling and interactions: `docs/style.css`, `docs/script.js`

The documentation distinguishes project concepts and goals from verified deployed features. Review all token addresses, technical claims, and links before publishing.

## Local yield prototype

`yield-lab/` contains the Atlas Valley Yield Lab v0.1, a Python-only local simulation of deposits, withdrawals and staking-style balance movements. Start it with `python3 yield-lab/app.py` and open `http://127.0.0.1:8787`. It does not connect to wallets, blockchain networks, validators or real yield providers; `DEMO` units have no value. See `yield-lab/protocol.md` for the accounting rules and verification limits.

`atlaslabs/` contains the v0.2 GitHub Pages route: `/atlaslabs/` for the demo lab and `/atlaslabs/login` for the wallet-access page. WalletConnect is not live yet; the Reown Project ID, chain configuration and a server-side signature-verification service are still required. Version archives are saved in `draft/` as soon as each version is created.
