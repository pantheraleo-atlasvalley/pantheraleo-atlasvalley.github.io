# Atlas Valley Wallet v0.2.3

La v0.2.3 aggiunge una schermata di accesso che apre il modal Reown AppKit per collegare un wallet Solana tramite WalletConnect o Phantom. Dopo la connessione mostra la dashboard di lettura SOL mainnet.

## Avvio su Arch Linux
Dalla radice del progetto esegui `python3 atlaslabs-v023/COM/start.py` e apri <http://127.0.0.1:8787/>. Interrompi i servizi con `Ctrl+C`. Reown AppKit è incluso in un bundle locale; per rigenerarlo usa `npm install && npm run build` nella cartella `atlaslabs-v023`. Il collegamento WalletConnect richiede internet. Il Project ID client è in `config.js`.

Il login collega il wallet e rende disponibile l'indirizzo pubblico; non dimostra identità tramite firma e non è una sessione autenticata lato server. La pagina non firma né invia transazioni. Per uso pubblico, aggiungere l'origine HTTPS in allowlist Reown se necessario e implementare autenticazione server-side con nonce e firma verificata.
