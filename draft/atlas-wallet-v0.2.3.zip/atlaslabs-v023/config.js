/* Reown Project ID: client ID, never a wallet secret. */
window.ATLASLABS_CONFIG = Object.freeze({
  version: '0.2.3',
  reownProjectId: 'd139d2fa74fac327f03730c8bac32dc5',
  appName: 'Atlas Valley Wallet',
});
