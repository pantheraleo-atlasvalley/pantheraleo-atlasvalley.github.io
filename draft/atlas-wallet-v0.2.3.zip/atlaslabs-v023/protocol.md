# Atlas Valley Wallet v0.2.3

- La schermata iniziale nasconde la dashboard fino al collegamento di un wallet.
- Reown AppKit presenta le opzioni Solana; Phantom può essere selezionato come wallet iniettato o tramite WalletConnect.
- Il login condivide l'indirizzo pubblico dopo l'approvazione del wallet. Non chiede una firma.
- Il backend Python legge il saldo SOL da Solana mainnet-beta tramite RPC `getBalance`.
- L'account $ARKV richiede ancora il mint address ufficiale.
- Nessuna transazione, deposito o staking è attivo.

Questo gate è un controllo dell'interfaccia. Non è autenticazione server-side: per proteggere dati o funzioni occorrono nonce monouso, firma del wallet verificata dal backend e sessione server.
