# Yield Lab v0.1

Interfaccia Python locale per esplorare il flusso contabile di un futuro prodotto. È una **simulazione**, non collega wallet né blockchain e non tratta asset reali.

## Avvio

Richiede Python 3.10+ e usa solo la libreria standard:

```bash
python3 yield-lab/app.py
```

Apri <http://127.0.0.1:8787>. Per chiudere, premi `Ctrl+C` nel terminale. Il registro viene salvato in `yield-lab/yield-lab.sqlite3`; cancellando quel file si azzera il prototipo.

Per scegliere un'altra porta: `YIELD_LAB_PORT=8788 python3 yield-lab/app.py`.

Leggi [protocol.md](protocol.md) per regole contabili, limiti della verifica hash-chain e prerequisiti per qualunque integrazione con fondi reali.
