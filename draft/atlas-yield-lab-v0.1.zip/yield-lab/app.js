const labels={deposit:'Deposito simulato',withdraw:'Prelievo simulato',stake:'Allocazione simulata',unstake:'Rientro simulato'};
const symbols={deposit:'↓',withdraw:'↑',stake:'◈',unstake:'↙',genesis:'·'};
let state=null;

function safe(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function units(value){return Number(value).toLocaleString('it-IT',{maximumFractionDigits:0});}
function shortHash(value){return `${value.slice(0,10)}…${value.slice(-8)}`;}
function stamp(value){return new Intl.DateTimeFormat('it-IT',{dateStyle:'short',timeStyle:'short'}).format(new Date(value));}

async function calculateHash(event){
  const input={sequence:event.sequence,created_at:event.created_at,kind:event.kind,amount:event.amount,fee:event.fee,note:event.note,previous_hash:event.previous_hash};
  const bytes=new TextEncoder().encode(JSON.stringify(Object.fromEntries(Object.entries(input).sort(([a],[b])=>a.localeCompare(b)))));
  const digest=await crypto.subtle.digest('SHA-256',bytes);
  return [...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join('');
}
async function verifyInBrowser(events,total){
  if(events.length!==total || !events.length)return false;
  let previous='0'.repeat(64);
  for(let i=0;i<events.length;i++){
    const event=events[i];
    if(event.sequence!==i+1 || event.previous_hash!==previous || await calculateHash(event)!==event.event_hash)return false;
    previous=event.event_hash;
  }
  return true;
}
async function refresh(){
  const response=await fetch('/api/state',{cache:'no-store'});if(!response.ok)throw new Error('Il registro locale non risponde.');
  state=await response.json();
  document.querySelector('#available').textContent=units(state.state.available);
  document.querySelector('#staked').textContent=units(state.state.staked);
  document.querySelector('#fee').textContent=`${units(Math.ceil(Number(document.querySelector('#amount').value||0)*state.fee_bps/10000))} DEMO`;
  document.querySelector('#eventCount').textContent=`${state.total_events} eventi`;
  const browserVerified=await verifyInBrowser([...state.events].reverse(),state.total_events);
  const valid=state.verified&&browserVerified;
  const badge=document.querySelector('#verified');badge.classList.toggle('invalid',!valid);
  badge.innerHTML=`<span></span>${valid?'Registro verificato':'Verifica non riuscita'}`;
  document.querySelector('.sync').innerHTML='<i></i> Registro aggiornato';
  const rows=state.events.map(event=>`<tr><td><div class="event-type"><span class="event-icon ${safe(event.kind)}">${symbols[event.kind]||'·'}</span><span>${safe(labels[event.kind]||'Inizio registro')}</span></div></td><td class="timestamp">${stamp(event.created_at)}</td><td>${units(event.amount)} DEMO</td><td>${units(event.fee)} DEMO</td><td class="event-hash" title="${safe(event.event_hash)}">${shortHash(event.event_hash)}</td></tr>`).join('');
  document.querySelector('#ledger').innerHTML=rows||'<tr><td colspan="5" class="empty">Nessun evento nel registro.</td></tr>';
}

function currentAction(){return document.querySelector('.tab.active').dataset.action;}
function updateAction(){
  const action=currentAction();
  document.querySelector('#submitButton').innerHTML=`${labels[action].replace(' simulata','').replace(' simulato','')} <span>→</span>`;
  document.querySelector('#maxButton').hidden=!['withdraw','stake','unstake'].includes(action);
  document.querySelector('label[for="amount"] span').textContent=action==='deposit'?'DEMO create localmente':'in DEMO';
  document.querySelector('#amount').max=action==='unstake'?state?.state.staked??0:['withdraw','stake'].includes(action)?state?.state.available??0:1000000000;
  document.querySelector('#fee').textContent='0 DEMO';
  document.querySelector('#formMessage').textContent='';
}

document.querySelectorAll('.tab').forEach(tab=>tab.addEventListener('click',()=>{
  document.querySelectorAll('.tab').forEach(item=>{item.classList.remove('active');item.setAttribute('aria-selected','false');});
  tab.classList.add('active');tab.setAttribute('aria-selected','true');updateAction();
}));
document.querySelector('#amount').addEventListener('input',()=>{
  const amount=Number(document.querySelector('#amount').value||0);
  document.querySelector('#fee').textContent=`${units(Math.ceil(amount*(state?.fee_bps||0)/10000))} DEMO`;
});
document.querySelector('#maxButton').addEventListener('click',()=>{
  const key=currentAction()==='unstake'?'staked':'available';document.querySelector('#amount').value=state?.state[key]||0;
  document.querySelector('#amount').dispatchEvent(new Event('input'));
});
document.querySelector('#actionForm').addEventListener('submit',async event=>{
  event.preventDefault();const message=document.querySelector('#formMessage');const button=document.querySelector('#submitButton');
  button.disabled=true;message.className='form-message';message.textContent='Aggiornamento del registro…';
  try{
    const amount=Number(document.querySelector('#amount').value);
    const response=await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kind:currentAction(),amount})});
    const result=await response.json();if(!response.ok)throw new Error(result.error||'Operazione non riuscita.');
    document.querySelector('#amount').value='';await refresh();updateAction();message.textContent=`Evento registrato · ${result.hash.slice(0,12)}…`;
  }catch(error){message.className='form-message error';message.textContent=error.message;}
  finally{button.disabled=false;}
});

refresh().then(updateAction).catch(error=>{document.querySelector('#verified').classList.add('invalid');document.querySelector('#verified').innerHTML='<span></span>Registro non disponibile';document.querySelector('#ledger').innerHTML=`<tr><td colspan="5" class="empty">${safe(error.message)}</td></tr>`;});
