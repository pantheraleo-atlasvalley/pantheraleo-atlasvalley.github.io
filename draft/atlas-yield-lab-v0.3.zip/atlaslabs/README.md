# Atlas Valley Yield Lab v0.3

Percorsi pubblici GitHub Pages: `/atlaslabs/` (landing), `/atlaslabs/login/` (connessione) e `/atlaslabs/core/` (Wallet App Atlas Valley).

## Cosa include

- Connessione multi-chain tramite Reown AppKit: Solana, Ethereum e Polygon.
- Solana è la rete iniziale preferita per SOL e ARKV; la scelta effettiva avviene nel modal Reown.
- Il core mostra solo lo stato pubblico della connessione. Non invia firme o transazioni e non sposta fondi.
- Il core presenta SOL e ARKV come asset da osservare, senza mostrare saldi finché non saranno configurati RPC e mint verificato.
- Il codice separa l'interfaccia di connessione dall'area core per poter aggiungere in futuro adapter di altre famiglie blockchain.

Il Project ID in `config.js` è un identificatore client pubblico, non una chiave privata. L'SDK AppKit è caricato da esm.sh; per usare il sito serve una connessione internet. Prima della pubblicazione occorre aggiungere e verificare l'origine del sito nella allowlist Reown. La pagina dashboard fornita mostrava la allowlist vuota.

La connessione wallet non equivale a un'identità autenticata dal server. Un login verificato richiederà una challenge monouso, una firma esplicita e verifica server-side. Prima di visualizzare saldi ARKV va confermato il mint ufficiale da fonte del progetto, per evitare di associare token omonimi.

## Limiti della v0.3

Questa versione configura le famiglie EVM e Solana; non dichiara supporto universale per ogni blockchain. Altre reti richiedono adapter o un connettore universale specifico, rete configurata e wallet compatibili. Nessuna strategia di rendimento è attiva. La versione precedente v0.2 resta nell'archivio `draft/atlas-yield-lab-v0.2.zip`.
