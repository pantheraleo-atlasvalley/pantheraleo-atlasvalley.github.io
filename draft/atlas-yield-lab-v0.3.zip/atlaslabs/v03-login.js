const config = window.ATLASLABS_CONFIG;
const button = document.querySelector('#connectButton');
const label = document.querySelector('#buttonLabel');
const feedback = document.querySelector('#feedback');
let appKit;

async function makeAppKit() {
  if (appKit) return appKit;
  feedback.textContent = 'Caricamento del modulo WalletConnect…';
  const [appKitModule, ethersModule, solanaModule, networks] = await Promise.all([
    import('https://esm.sh/@reown/appkit@1?bundle'),
    import('https://esm.sh/@reown/appkit-adapter-ethers@1?bundle'),
    import('https://esm.sh/@reown/appkit-adapter-solana@1?bundle'),
    import('https://esm.sh/@reown/appkit@1/networks?bundle'),
  ]);
  appKit = appKitModule.createAppKit({
    adapters: [new ethersModule.EthersAdapter(), new solanaModule.SolanaAdapter()],
    networks: [networks.solana, networks.mainnet, networks.polygon],
    defaultNetwork: networks.solana,
    projectId: config.reownProjectId,
    metadata: {
      name: config.appName,
      description: 'Multi-chain wallet access for Atlas Valley Yield Lab',
      url: window.location.origin,
      icons: [`${window.location.origin}/atlaslabs/icon.svg`],
    },
    features: { analytics: false, email: false, socials: false, onramp: false, swaps: false },
  });
  return appKit;
}

button.addEventListener('click', async () => {
  if (!config?.reownProjectId) return;
  button.disabled = true;
  label.textContent = 'Apro il collegamento…';
  try {
    const modal = await makeAppKit();
    modal.subscribeAccount((account) => {
      if (account?.isConnected && account.address) {
        sessionStorage.setItem('atlas-wallet-connected', 'true');
        window.location.assign('/atlaslabs/core/');
      }
    });
    feedback.textContent = 'Scegli un wallet e controlla la rete indicata. Il login non richiede firme.';
    await modal.open({ view: 'Connect' });
  } catch (error) {
    console.error('Wallet connection setup failed', error);
    feedback.textContent = 'Non è stato possibile avviare WalletConnect. Controlla la connessione e che il dominio sia autorizzato nel progetto Reown.';
    button.disabled = false;
    label.textContent = 'Connetti con WalletConnect';
  }
});
