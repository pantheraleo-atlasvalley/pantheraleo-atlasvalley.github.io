# Atlas Valley Wallet Core — specifica v0.3

## Scopo

Separare l'accesso wallet dall'area core e rendere esplicito lo stato della configurazione. Questa release è un prototipo di connessione e interfaccia; non è un protocollo di custodia o rendimento.

## Connessione

- SDK: Reown AppKit.
- Namespace abilitati: EVM (Ethereum e Polygon per il prototipo) e Solana (mainnet).
- Rete preferita: Solana, per l'osservazione pianificata di SOL e ARKV.
- Il Project ID Reown è pubblico e viene usato esclusivamente dal client.
- L'indirizzo pubblico e la rete sono dati del wallet, non prova di autenticazione server-side.

## Core

- Visualizza solo dati di sessione pubblici.
- Non chiede seed phrase, non firma messaggi e non crea transazioni.
- SOL e ARKV sono elencati come asset di interesse, ma i saldi restano disabilitati finché non si configurano fonti RPC e mint ARKV verificato.
- Nessun deposito, prelievo, staking, validator, farming o rendimento è attivo.

## Estensione multi-chain

Ogni nuova famiglia di reti deve essere aggiunta con adapter compatibile, reti identificate esplicitamente, wallet supportati, fonti RPC documentate e test di sola lettura prima di mostrare dati. “Multi-chain” non significa compatibilità automatica con ogni blockchain.

## Passi successivi

1. Verificare l'origine pubblica nella allowlist Reown.
2. Provare la connessione Solana ed EVM con wallet di test, senza firme o transazioni.
3. Confermare da fonte ufficiale il mint del token ARKV e la rete.
4. Aggiungere letture di saldo per SOL e ARKV con endpoint e limiti documentati.
5. Progettare l'autenticazione server-side prima di proteggere dati o azioni utente.
