const config = window.ATLASLABS_CONFIG;
const status = document.querySelector('#connectionStatus');
const address = document.querySelector('#walletAddress');
const network = document.querySelector('#walletNetwork');
const connectButton = document.querySelector('#accountButton');
const copyButton = document.querySelector('#copyAddress');
const disconnectButton = document.querySelector('#disconnectButton');
let appKit;
let accountState;
const networkNameById = { 1: 'Ethereum', 137: 'Polygon', 'solana:mainnet': 'Solana Mainnet' };

function displayAccount(state = {}) {
  accountState = state;
  if (state.isConnected && state.address) {
    address.textContent = `${state.address.slice(0, 8)}…${state.address.slice(-7)}`;
    address.title = state.address;
    const caipParts = state.caipAddress?.split(':') ?? [];
    const caipNetwork = `${caipParts[0]}:${caipParts[1]}`;
    const chainId = state.chainId ?? caipParts[1];
    network.textContent = networkNameById[caipNetwork] ?? networkNameById[Number(chainId)] ?? 'Rete wallet';
    status.textContent = 'COLLEGATO';
    status.classList.add('online');
    connectButton.textContent = 'Wallet collegato';
    copyButton.disabled = false;
    disconnectButton.disabled = false;
    return;
  }
  address.textContent = 'Nessun wallet collegato';
  address.removeAttribute('title');
  network.textContent = 'Non collegata';
  status.textContent = 'NON COLLEGATO';
  status.classList.remove('online');
  connectButton.textContent = 'Connetti wallet';
  copyButton.disabled = true;
  disconnectButton.disabled = true;
}

async function initialize() {
  if (!config?.reownProjectId) {
    status.textContent = 'CONFIGURAZIONE MANCANTE';
    return;
  }
  try {
    const [appKitModule, ethersModule, solanaModule, networks] = await Promise.all([
      import('https://esm.sh/@reown/appkit@1?bundle'),
      import('https://esm.sh/@reown/appkit-adapter-ethers@1?bundle'),
      import('https://esm.sh/@reown/appkit-adapter-solana@1?bundle'),
      import('https://esm.sh/@reown/appkit@1/networks?bundle'),
    ]);
    appKit = appKitModule.createAppKit({
      adapters: [new ethersModule.EthersAdapter(), new solanaModule.SolanaAdapter()],
      networks: [networks.solana, networks.mainnet, networks.polygon],
      defaultNetwork: networks.solana,
      projectId: config.reownProjectId,
      metadata: { name: config.appName, description: 'Wallet access for Atlas Valley Yield Lab', url: window.location.origin },
      features: { analytics: false, email: false, socials: false, onramp: false, swaps: false },
      enableWallets: true,
    });
    appKit.subscribeAccount(displayAccount);
    displayAccount(appKit.getAccount());
  } catch (error) {
    console.error('Wallet state unavailable', error);
    status.textContent = 'WALLET SDK NON DISPONIBILE';
  }
}

connectButton.addEventListener('click', async () => {
  if (!appKit) return;
  await appKit.open({ view: 'Connect' });
});
copyButton.addEventListener('click', async () => {
  if (accountState?.address) await navigator.clipboard.writeText(accountState.address);
});
disconnectButton.addEventListener('click', async () => {
  if (!appKit) return;
  await appKit.disconnect();
});

initialize();
