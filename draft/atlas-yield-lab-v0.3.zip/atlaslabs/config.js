/* Reown Project ID is a public client identifier. Never put private keys here. */
window.ATLASLABS_CONFIG = Object.freeze({
  version: "0.3",
  reownProjectId: "d139d2fa74fac327f03730c8bac32dc5",
  appName: "Atlas Valley Yield Lab",
});
