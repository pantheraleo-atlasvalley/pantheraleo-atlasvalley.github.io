# Atlas Valley Wallet v0.2.2

## Funzioni attive
- Connessione facoltativa al provider Phantom Solana nel browser.
- Lettura pubblica del saldo SOL dal cluster Solana mainnet-beta tramite RPC `getBalance` con commitment `finalized`.
- Il backend locale serve la pagina; il frontend inoltra la richiesta al backend Python, che interroga il nodo RPC pubblico.

## Non attivo
- Firma di messaggi o transazioni.
- Invio, deposito, staking, custodia o gestione di chiavi.
- Lettura di $ARKV finché non viene configurato il mint address ufficiale.

La connessione Phantom condivide l'indirizzo pubblico dopo approvazione dell'utente. Phantom inietta il provider sulle pagine HTTPS, localhost e 127.0.0.1. I saldi mostrati sono letture on-chain; non sono stime di rendimento. L'endpoint RPC pubblico può imporre limiti di traffico.
