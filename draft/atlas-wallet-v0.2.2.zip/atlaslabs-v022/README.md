# Atlas Valley Wallet v0.2.2

Versione di lettura mainnet di Atlas Wallet. Connette Phantom per mostrare l'indirizzo Solana e il saldo SOL reale. Il frontend Python passa la richiesta di lettura al backend Python, che interroga Solana mainnet. Il mint $ARKV non è ancora configurato.

## Avvio su Arch Linux
Dalla radice del progetto: `python3 atlaslabs-v022/COM/start.py`, poi apri <http://127.0.0.1:8787/>. `Ctrl+C` chiude i processi. Nessuna dipendenza Python o Node aggiuntiva.

Le transazioni, i depositi e lo staking non sono attivi. Nessuna chiave privata viene letta o salvata dall'app. Per abilitare $ARKV serve il mint ufficiale; per ogni funzione che muove asset servono il programma on-chain e le sue regole verificabili.
