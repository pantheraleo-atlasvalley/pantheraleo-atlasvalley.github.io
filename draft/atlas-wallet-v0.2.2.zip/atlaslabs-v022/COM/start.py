#!/usr/bin/env python3
"""Start both local Python services; Ctrl-C stops them together."""
import signal, subprocess, sys, time
from pathlib import Path
HERE = Path(__file__).resolve().parent
children = [subprocess.Popen([sys.executable, str(HERE / name)]) for name in ('backend.py', 'frontend.py')]
try:
    while True:
        failed = next((p for p in children if p.poll() is not None), None)
        if failed: raise SystemExit(failed.returncode or 1)
        time.sleep(0.5)
except KeyboardInterrupt:
    pass
finally:
    for proc in children:
        if proc.poll() is None: proc.terminate()
    for proc in children:
        try: proc.wait(timeout=3)
        except subprocess.TimeoutExpired: proc.kill()
