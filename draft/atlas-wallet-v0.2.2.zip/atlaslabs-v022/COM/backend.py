#!/usr/bin/env python3
"""Read-only Solana mainnet RPC adapter. It never signs or sends transactions."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
import json

HOST, PORT = '127.0.0.1', 8788
RPC = 'https://api.mainnet-beta.solana.com'
ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'

def valid_pubkey(value):
    if not value or len(value) > 44: return False
    n = 0
    try:
        for char in value: n = n * 58 + ALPHABET.index(char)
    except ValueError:
        return False
    raw = n.to_bytes((n.bit_length() + 7) // 8, 'big')
    raw = b'\0' * (len(value) - len(value.lstrip('1'))) + raw
    return len(raw) == 32

class Handler(BaseHTTPRequestHandler):
    server_version = 'AtlasWalletReadOnly/0.2.2'
    def log_message(self, fmt, *args): print('backend:', fmt % args)
    def send_json(self, status, obj):
        data = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(status); self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(data))); self.send_header('Cache-Control', 'no-store'); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        url = urlsplit(self.path)
        if url.path == '/health': return self.send_json(200, {'ok': True, 'service': 'read-only-mainnet-rpc'})
        if url.path != '/api/sol-balance': return self.send_json(404, {'error': 'Endpoint non trovato.'})
        address = parse_qs(url.query).get('address', [''])[0]
        if not valid_pubkey(address): return self.send_json(400, {'error': 'Indirizzo Solana non valido.'})
        payload = json.dumps({'jsonrpc':'2.0','id':1,'method':'getBalance','params':[address,{'commitment':'finalized'}]}).encode()
        request = Request(RPC, data=payload, headers={'Content-Type':'application/json'}, method='POST')
        try:
            with urlopen(request, timeout=12) as response: result = json.loads(response.read())
            if 'error' in result: return self.send_json(502, {'error': 'Nodo Solana: ' + result['error'].get('message','errore RPC')})
            return self.send_json(200, {'address': address, 'lamports': result['result']['value'], 'slot': result['result']['context']['slot'], 'cluster': 'mainnet-beta', 'commitment': 'finalized'})
        except (HTTPError, URLError, TimeoutError, OSError, ValueError, KeyError) as exc:
            return self.send_json(502, {'error': f'Lettura RPC non riuscita: {exc}'})
    def do_POST(self): return self.send_json(405, {'error': 'API in sola lettura; POST disabilitato.'})

if __name__ == '__main__':
    print(f'Atlas v0.2.2 read-only backend su http://{HOST}:{PORT}; RPC mainnet configurato.')
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
