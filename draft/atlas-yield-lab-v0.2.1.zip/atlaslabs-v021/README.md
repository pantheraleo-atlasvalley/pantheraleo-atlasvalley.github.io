# Atlas Valley Yield Lab v0.2.1

Modello wallet dimostrativo basato sull'interfaccia della v0.2. Il frontend in Python serve la pagina e inoltra le chiamate `/api/*`; un secondo processo Python gestisce validazione, saldo e registro SQLite con hash-chain.

## Avvio su Arch Linux

Dalla cartella principale del progetto:

```bash
python3 atlaslabs-v021/COM/start.py
```

Apri <http://127.0.0.1:8787/>. Interrompi entrambi i processi con `Ctrl+C`. Non servono dipendenze esterne, pacchetti Python o Node.

Per avviare separatamente, usa due terminali: `python3 atlaslabs-v021/COM/backend.py` e `python3 atlaslabs-v021/COM/frontend.py`.

Il database locale è `atlaslabs-v021/data/wallet.sqlite3`. Il frontend è su `127.0.0.1:8787` e il backend solo su `127.0.0.1:8788`; il frontend fa da proxy same-origin.

**Limiti:** DEMO è un'unità fittizia. Non c'è login, gestione di chiavi, connessione a wallet, blockchain, staking reale, rendimento, invio o custodia di criptovalute. Il registro dimostra l'architettura client-server e la verifica hash-chain, ma un database locale non è una prova pubblica o immutabile.
