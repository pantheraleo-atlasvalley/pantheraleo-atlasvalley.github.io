#!/usr/bin/env python3
"""Local demo wallet backend: SQLite ledger and hash-chain verification."""
from __future__ import annotations
import hashlib
import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = Path(os.environ.get('ATLAS_WALLET_DB', ROOT / 'data' / 'wallet.sqlite3'))
HOST, PORT = '127.0.0.1', int(os.environ.get('ATLAS_BACKEND_PORT', '8788'))
FIELDS = ('sequence', 'created_at', 'kind', 'amount', 'fee', 'note', 'previous_hash')
KINDS = {'deposit', 'withdraw', 'stake', 'unstake'}
NOTES = {
    'deposit': 'Deposito simulato: DEMO aggiunti solo nel registro locale.',
    'withdraw': 'Prelievo simulato: nessuna criptovaluta trasferita.',
    'stake': 'Allocazione simulata; nessun validator o protocollo esterno coinvolto.',
    'unstake': 'Rientro simulato dall’allocazione.',
}

def canonical(event):
    return json.dumps({k: event[k] for k in FIELDS}, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def digest(event):
    return hashlib.sha256(canonical(event).encode()).hexdigest()

def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute('''CREATE TABLE IF NOT EXISTS events (
      sequence INTEGER PRIMARY KEY, created_at TEXT NOT NULL, kind TEXT NOT NULL,
      amount INTEGER NOT NULL, fee INTEGER NOT NULL, note TEXT NOT NULL,
      previous_hash TEXT NOT NULL, event_hash TEXT NOT NULL UNIQUE)''')
    if db.execute('SELECT COUNT(*) FROM events').fetchone()[0] == 0:
        event = {'sequence': 1, 'created_at': datetime.now(timezone.utc).isoformat(),
                 'kind': 'genesis', 'amount': 0, 'fee': 0,
                 'note': 'Registro demo locale inizializzato; nessun asset reale.',
                 'previous_hash': '0' * 64}
        db.execute('INSERT INTO events VALUES (?,?,?,?,?,?,?,?)',
                   (*[event[k] for k in FIELDS], digest(event)))
        db.commit()
    return db

@contextmanager
def database():
    db = connect()
    try:
        yield db
    finally:
        db.close()

def read_events(db):
    return [dict(row) for row in db.execute('SELECT * FROM events ORDER BY sequence')]

def valid_chain(events):
    previous = '0' * 64
    for index, event in enumerate(events, 1):
        if event['sequence'] != index or event['previous_hash'] != previous or digest(event) != event['event_hash']:
            return False
        previous = event['event_hash']
    return bool(events)

def calculate(events):
    result = {'available': 0, 'staked': 0}
    for event in events:
        amount, kind = event['amount'], event['kind']
        if kind == 'deposit': result['available'] += amount - event['fee']
        elif kind == 'withdraw': result['available'] -= amount
        elif kind == 'stake': result['available'] -= amount; result['staked'] += amount
        elif kind == 'unstake': result['staked'] -= amount; result['available'] += amount
    return result

class Handler(BaseHTTPRequestHandler):
    server_version = 'AtlasWalletBackend/0.2.1'
    def log_message(self, fmt, *args): print('backend:', fmt % args)
    def send_json(self, status, obj):
        data = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(status); self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(data))); self.send_header('Cache-Control', 'no-store'); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        if self.path not in ('/api/state', '/health'):
            return self.send_json(404, {'error': 'Endpoint non trovato.'})
        if self.path == '/health': return self.send_json(200, {'ok': True, 'service': 'backend', 'version': '0.2.1'})
        with database() as db:
            events = read_events(db)
            return self.send_json(200, {'events': events, 'balances': calculate(events), 'verified': valid_chain(events), 'storage': 'sqlite'})
    def do_POST(self):
        if self.path != '/api/action': return self.send_json(404, {'error': 'Endpoint non trovato.'})
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if length > 4096: return self.send_json(413, {'error': 'Richiesta troppo grande.'})
            payload = json.loads(self.rfile.read(length) or b'{}')
            kind, amount = payload.get('kind'), payload.get('amount')
            if kind not in KINDS or isinstance(amount, bool) or not isinstance(amount, int) or not 1 <= amount <= 1_000_000_000:
                return self.send_json(400, {'error': 'Tipo operazione o importo non valido.'})
            with database() as db:
                db.execute('BEGIN IMMEDIATE')
                events = read_events(db)
                if not valid_chain(events): return self.send_json(409, {'error': 'Registro non valido: operazione bloccata.'})
                balance = calculate(events)
                funds = balance['staked'] if kind == 'unstake' else balance['available']
                if kind != 'deposit' and amount > funds:
                    return self.send_json(409, {'error': f'Saldo insufficiente: {funds} DEMO.'})
                event = {'sequence': len(events) + 1, 'created_at': datetime.now(timezone.utc).isoformat(),
                         'kind': kind, 'amount': amount, 'fee': 0, 'note': NOTES[kind],
                         'previous_hash': events[-1]['event_hash']}
                db.execute('INSERT INTO events VALUES (?,?,?,?,?,?,?,?)',
                           (*[event[k] for k in FIELDS], digest(event)))
            return self.send_json(201, {'ok': True, 'event': {**event, 'event_hash': digest(event)}})
        except (ValueError, TypeError, json.JSONDecodeError):
            return self.send_json(400, {'error': 'JSON non valido.'})
        except Exception as exc:
            return self.send_json(500, {'error': f'Errore backend: {exc}'})

if __name__ == '__main__':
    connect().close()
    print(f'Atlas v0.2.1 backend in ascolto su http://{HOST}:{PORT}; DB: {DB_PATH}')
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
