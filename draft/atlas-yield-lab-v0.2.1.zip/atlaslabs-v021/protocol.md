# Protocollo dimostrativo v0.2.1

- Il client web è servito da `COM/frontend.py`.
- Le richieste API passano dal frontend al backend Python su loopback.
- `COM/backend.py` convalida le operazioni e registra gli eventi in SQLite.
- Gli eventi formano una catena SHA-256: ogni evento include l'hash precedente.
- Genesi, importi e commissioni sono espressi in unità fittizie DEMO. La commissione è zero.
- Deposit, withdraw, stake e unstake modificano esclusivamente il registro dimostrativo.
- Il backend verifica la catena prima di accettare un nuovo movimento e controlla il saldo.

Questa versione non gestisce account, wallet, chiavi private, token, transazioni blockchain, validator o rendimenti. Il database si trova sul computer locale e non è replicato né pubblicato; hash-chain locale non equivale a consenso o immutabilità on-chain.
