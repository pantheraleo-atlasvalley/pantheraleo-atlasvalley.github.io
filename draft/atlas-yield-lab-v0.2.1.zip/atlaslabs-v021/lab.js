const labels={deposit:'Deposito simulato',withdraw:'Prelievo simulato',stake:'Allocazione simulata',unstake:'Rientro simulato'};
const symbols={deposit:'↓',withdraw:'↑',stake:'◈',unstake:'↙',genesis:'·'};
const canonicalFields=['sequence','created_at','kind','amount','fee','note','previous_hash'];
let events=[],balances={available:0,staked:0},verified=false;
function safe(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function units(value){return Number(value).toLocaleString('it-IT',{maximumFractionDigits:0});}
function shortHash(value){return `${value.slice(0,10)}…${value.slice(-8)}`;}
function canonical(event){const object={};for(const key of canonicalFields)object[key]=event[key];return JSON.stringify(Object.fromEntries(Object.entries(object).sort(([a],[b])=>a<b?-1:a>b?1:0)));}
async function hashEvent(event){const data=new TextEncoder().encode(canonical(event));const digest=await crypto.subtle.digest('SHA-256',data);return [...new Uint8Array(digest)].map(byte=>byte.toString(16).padStart(2,'0')).join('');}
async function verify(){let previous='0'.repeat(64);for(let i=0;i<events.length;i++){const event=events[i];if(event.sequence!==i+1||event.previous_hash!==previous||await hashEvent(event)!==event.event_hash)return false;previous=event.event_hash;}return events.length>0;}
function time(value){return new Intl.DateTimeFormat('it-IT',{dateStyle:'short',timeStyle:'short'}).format(new Date(value));}
async function request(path,options={}){const response=await fetch(path,{cache:'no-store',...options,headers:{'Content-Type':'application/json',...(options.headers||{})}});const data=await response.json();if(!response.ok)throw new Error(data.error||`Errore HTTP ${response.status}`);return data;}
async function refresh(){
  const data=await request('/api/state');events=data.events;balances=data.balances;verified=Boolean(data.verified)&&await verify();
  document.querySelector('#available').textContent=units(balances.available);document.querySelector('#staked').textContent=units(balances.staked);
  document.querySelector('#eventCount').textContent=`${events.length} eventi`;
  const badge=document.querySelector('#verified');badge.classList.toggle('invalid',!verified);badge.innerHTML=`<span></span>${verified?'Registro verificato':'Verifica non riuscita'}`;
  document.querySelector('#submitButton').disabled=!verified;
  const rows=[...events].reverse().map(event=>`<tr><td><div class="event-type"><span class="event-icon ${safe(event.kind)}">${symbols[event.kind]||'·'}</span><span>${safe(labels[event.kind]||'Inizio registro')}</span></div></td><td class="timestamp">${time(event.created_at)}</td><td>${units(event.amount)} DEMO</td><td>${units(event.fee)} DEMO</td><td class="event-hash" title="${safe(event.event_hash)}">${shortHash(event.event_hash)}</td></tr>`).join('');
  document.querySelector('#ledger').innerHTML=rows||'<tr><td colspan="5" class="empty">Nessun evento nel registro.</td></tr>';
}
function currentAction(){return document.querySelector('.tab.active').dataset.action;}
function updateAction(){const action=currentAction();document.querySelector('#submitButton').innerHTML=`${labels[action].replace(' simulata','').replace(' simulato','')} <span>→</span>`;document.querySelector('#maxButton').hidden=!['withdraw','stake','unstake'].includes(action);document.querySelector('#amount').max=action==='unstake'?balances.staked:['withdraw','stake'].includes(action)?balances.available:1000000000;document.querySelector('#formMessage').textContent='';}
document.querySelectorAll('.tab').forEach(tab=>tab.addEventListener('click',()=>{document.querySelectorAll('.tab').forEach(item=>{item.classList.remove('active');item.setAttribute('aria-selected','false');});tab.classList.add('active');tab.setAttribute('aria-selected','true');updateAction();}));
document.querySelector('#maxButton').addEventListener('click',()=>{document.querySelector('#amount').value=currentAction()==='unstake'?balances.staked:balances.available;});
document.querySelector('#actionForm').addEventListener('submit',async event=>{event.preventDefault();const button=document.querySelector('#submitButton'),message=document.querySelector('#formMessage');const amount=Number(document.querySelector('#amount').value),kind=currentAction();button.disabled=true;message.className='form-message';if(!Number.isSafeInteger(amount)||amount<1||amount>1000000000){message.textContent='Inserisci un importo intero valido.';message.classList.add('error');button.disabled=false;return;}try{message.textContent='Invio al backend Python…';await request('/api/action',{method:'POST',body:JSON.stringify({kind,amount})});document.querySelector('#amount').value='';await refresh();updateAction();message.textContent='Evento salvato nel registro SQLite locale.';}catch(error){message.textContent=`Operazione non riuscita: ${error.message}`;message.classList.add('error');}finally{button.disabled=!verified;}});
(async()=>{try{await refresh();updateAction();}catch(error){const badge=document.querySelector('#verified');badge.classList.add('invalid');badge.innerHTML='<span></span>Backend non raggiungibile';document.querySelector('#ledger').innerHTML=`<tr><td colspan="5" class="empty">${safe(error.message)}. Avvia i servizi con python3 COM/start.py.</td></tr>`;document.querySelector('#submitButton').disabled=true;}})();
